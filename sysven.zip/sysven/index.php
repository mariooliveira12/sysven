<?php
    header('location:php/controller/cliente.php');   
?>