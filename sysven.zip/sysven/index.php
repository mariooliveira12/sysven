<?php
    header('location:php/controller/usuario.php?login');
?>