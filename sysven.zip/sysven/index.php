<?php
    header('location:php/controller/usuario.php?cadastro_form');
?>