<html>
<body>
<div class="card float-left " style="width: 18rem;margin-left: 80px;margin-right: 30px;">
  <img class="card-img-top" src="../../img/wallpaper_podcast.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Workshops</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="../view/usuario/categoria/podcast.php" class="btn btn-primary">Ver Podcasts</a>
  </div>
</div>
<div class="card float-left" style="width: 18rem;margin-right: 30px;">
  <img class="card-img-top" src="../../img/wallpaper_podcast.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Podcasts</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="../view/usuario/categoria/podcast.php" class="btn btn-primary">Ver Podcasts</a>
  </div>
</div>
<div class="card float-left " style="width: 18rem;margin-right: 30px;">
  <img class="card-img-top" src="../../img/wallpaper_podcast.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Lives</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="../view/usuario/categoria/podcast.php" class="btn btn-primary">Ver Podcasts</a>
  </div>
</div>
<div class="card float-left " style="width: 18rem;margin-top: 40px;margin-left: 80px; margin-right: 30px;">
  <img class="card-img-top" src="../../img/wallpaper_podcast.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Imagens</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="../view/usuario/categoria/podcast.php" class="btn btn-primary">Ver Podcasts</a>
  </div>
</div>
<div class="card float-left " style="width: 18rem;margin-top: 40px;margin-right: 30px;">
  <img class="card-img-top" src="../../img/wallpaper_podcast.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Videos</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="../view/usuario/categoria/podcast.php" class="btn btn-primary">Ver Podcasts</a>
  </div>
</div>

</body>
</html>