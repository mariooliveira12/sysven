<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Lista</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Id</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php foreach($usuarios as $u) : ?>
                    <tr>
                        <td><?=$u['id']?></td>
                        <td>
                            <a href="cliente.php?id=<?=$u['email']?>">
                                <?=$u['primeiro_nome']?>
                            </a>
                        </td>
                        <td><?=$u['email']?></td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>