<?php
    include_once '_sessao.php';
    isSession();
    include '../model/usuario_model.php';
    include '../view/header.php';

    //  function index(){
       $usuarios = listar();
           require_once '../view/cliente/index.php';
           //require '../model/usuario_model.php';
    // }
    include '../view/footer.php';
?>