<?php
    include 'dbfunctions.php';

    function inserir($nome, $sobrenome, $email, $senha){
        $sql = "INSERT INTO cliente(nome, sobrenome, email, senha) VALUES ('$nome', '$sobrenome', '$email', '$senha')";
        executarSQL($sql);
    }
    function listar(){
        $sql = "SELECT * FROM cliente";
        $resultado = consultarSQL($sql);
        return $resultado;
    }
    function buscar($id){
        $sql = "SELECT * FROM cliente WHERE id = '$id'";
        $resultado = consultarSQL($sql);
        return $resultado[0];
    }
    function atualizar($id, $nome, $sobrenome, $email, $senha){
        $sql = "UPDATE cliente SET nome = '$nome', sobrenome = '$sobrenome', email = '$email', senha = '$senha' WHERE id = '$id'";
        executarSQL($sql);
    }
    function excluir($id){
        $sql = "DELETE FROM cliente WHERE id = '$id'";
        executarSQL($sql);
    }
?>