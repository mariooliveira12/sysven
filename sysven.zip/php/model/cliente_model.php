<?php
    include 'dbfunctions.php';

    function inserir($nome, $email, $senha){
        $sql = "INSERT INTO usuario(nome, email, senha) VALUES ('$nome', '$email', '$senha')";
        executarSQL($sql);
    }
    function listar(){
        $sql = "SELECT * FROM usuario";
        $resultado = consultarSQL($sql);
        return $resultado;
    }
    function buscar($id){
        $sql = "SELECT * FROM usuario WHERE id = '$id'";
        $resultado = consultarSQL($sql);
        return $resultado[0];
    }
    function atualizar($id, $nome, $email, $senha){
        $sql = "UPDATE usuario SET nome = '$nome', email = '$email', senha = '$senha' WHERE id = '$id'";
        executarSQL($sql);
    }
    function excluir($id){
        $sql = "DELETE FROM usuario WHERE id = '$id'";
        executarSQL($sql);
    }
?>