<?php
include_once 'dbfunctions.php';

$email = $_POST['email'];
$senha = $_POST['senha'];

$querysql = mysqli_query(setConexao(),"select * from usuario where email='$email' and senha='$senha'");

$linha = mysqli_num_rows($querysql);

if($linha == 0){
	echo "Usuário ou senhas não encontrados!";
    header('location:login.php');
}else{
	header('location:categoria.php');
	
}
?>